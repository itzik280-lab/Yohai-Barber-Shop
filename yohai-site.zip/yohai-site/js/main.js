/* =====================================================================
   YOHAI BARBER SHOP — main.js
   Organized, dependency-free. Sections:
   1) CONFIG (replace placeholders here)  2) Header/nav  3) Mobile menu
   4) Scroll reveal  5) Active section spy  6) Gallery filter
   7) Booking multi-step flow + validation + WhatsApp
   ===================================================================== */
(function () {
  "use strict";

  /* ---------------------------------------------------------------
     1) CONFIG — ★ REPLACE THESE PLACEHOLDERS WITH REAL DETAILS ★
     --------------------------------------------------------------- */
  const CONFIG = {
    whatsapp: "972501234567",            // international format, no + or spaces
    businessName: "YOHAI Barber Shop",
    // Working hours used to build the time slots:
    slotsWeekday: ["09:00","09:45","10:30","11:15","12:00","13:30","14:15","15:00","15:45","16:30","17:15","18:00","18:45","19:30"],
    slotsFriday:  ["09:00","09:45","10:30","11:15","12:00","12:45","13:30"],
    closedDay: 6 // Saturday (0=Sun … 6=Sat)
  };

  const $  = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => Array.from(c.querySelectorAll(s));
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------------------------------------------------------------
     2) HEADER — solid background on scroll
     --------------------------------------------------------------- */
  const header = $("#header");
  const onScroll = () => header.classList.toggle("scrolled", window.scrollY > 24);
  onScroll();
  window.addEventListener("scroll", onScroll, { passive: true });

  /* ---------------------------------------------------------------
     3) MOBILE MENU
     --------------------------------------------------------------- */
  const burger = $("#burger");
  const mobileMenu = $("#mobileMenu");
  const toggleMenu = (open) => {
    const isOpen = open ?? !mobileMenu.classList.contains("open");
    mobileMenu.classList.toggle("open", isOpen);
    burger.classList.toggle("open", isOpen);
    burger.setAttribute("aria-expanded", String(isOpen));
    mobileMenu.setAttribute("aria-hidden", String(!isOpen));
    document.body.classList.toggle("no-scroll", isOpen);
  };
  burger.addEventListener("click", () => toggleMenu());
  $$("#mobileMenu a").forEach(a => a.addEventListener("click", () => toggleMenu(false)));
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") toggleMenu(false); });

  /* ---------------------------------------------------------------
     4) SCROLL REVEAL
     --------------------------------------------------------------- */
  const reveals = $$(".reveal");
  if (reduceMotion || !("IntersectionObserver" in window)) {
    reveals.forEach(el => el.classList.add("in"));
  } else {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(en => {
        if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); }
      });
    }, { threshold: 0.14, rootMargin: "0px 0px -6% 0px" });
    reveals.forEach(el => io.observe(el));
  }

  /* ---------------------------------------------------------------
     5) ACTIVE SECTION SPY (nav highlight)
     --------------------------------------------------------------- */
  const navLinks = $$(".nav__menu a");
  const sections = navLinks
    .map(a => $(a.getAttribute("href")))
    .filter(Boolean);
  if ("IntersectionObserver" in window && sections.length) {
    const spy = new IntersectionObserver((entries) => {
      entries.forEach(en => {
        if (en.isIntersecting) {
          const id = "#" + en.target.id;
          navLinks.forEach(a => a.classList.toggle("active", a.getAttribute("href") === id));
        }
      });
    }, { threshold: 0.4, rootMargin: "-30% 0px -50% 0px" });
    sections.forEach(s => spy.observe(s));
  }

  /* ---------------------------------------------------------------
     6) GALLERY FILTER
     --------------------------------------------------------------- */
  const filterBtns = $$(".gallery__filters button");
  const galleryItems = $$(".gallery__item");
  filterBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      filterBtns.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      const f = btn.dataset.filter;
      galleryItems.forEach(item => {
        const show = f === "all" || item.dataset.cat === f;
        item.classList.toggle("hide", !show);
      });
    });
  });

  /* ---------------------------------------------------------------
     7) BOOKING MULTI-STEP FLOW
     --------------------------------------------------------------- */
  const form = $("#bookingForm");
  if (form) {
    const panels = $$(".booking__panel", form);
    const stepEls = $$("#bookingSteps .st");
    let current = 1;
    const state = { service: "", price: 0, date: "", time: "", fullname: "", phone: "", email: "", notes: "" };

    /* --- build time slots based on chosen date --- */
    const dateInput = $("#date");
    const timeGrid = $("#timeGrid");

    // min date = today
    const today = new Date();
    const pad = n => String(n).padStart(2, "0");
    const toISO = d => `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
    dateInput.min = toISO(today);

    function buildSlots() {
      timeGrid.innerHTML = "";
      state.time = "";
      if (!dateInput.value) {
        timeGrid.innerHTML = '<p class="muted" style="grid-column:1/-1;font-size:.9rem">בחר תאריך כדי לראות שעות פנויות.</p>';
        return;
      }
      const d = new Date(dateInput.value + "T00:00:00");
      const day = d.getDay();
      if (day === CONFIG.closedDay) {
        timeGrid.innerHTML = '<p class="muted" style="grid-column:1/-1;font-size:.9rem">בשבת אנחנו סגורים — נא לבחור יום אחר.</p>';
        return;
      }
      const slots = (day === 5) ? CONFIG.slotsFriday : CONFIG.slotsWeekday;
      const isToday = dateInput.value === toISO(today);
      const nowMin = today.getHours()*60 + today.getMinutes();
      slots.forEach(t => {
        const [h, m] = t.split(":").map(Number);
        const chip = document.createElement("button");
        chip.type = "button";
        chip.className = "time-chip num";
        chip.textContent = t;
        if (isToday && (h*60+m) <= nowMin + 30) chip.classList.add("disabled");
        chip.addEventListener("click", () => {
          $$(".time-chip", timeGrid).forEach(c => c.classList.remove("selected"));
          chip.classList.add("selected");
          state.time = t;
          clearError("errTime");
        });
        timeGrid.appendChild(chip);
      });
    }
    dateInput.addEventListener("change", buildSlots);
    buildSlots();

    /* --- service selection styling --- */
    $$(".svc-opt input").forEach(r => {
      r.addEventListener("change", () => {
        $$(".svc-opt").forEach(o => o.classList.remove("selected"));
        r.closest(".svc-opt").classList.add("selected");
        state.service = r.value;
        state.price = Number(r.dataset.price || 0);
        clearError("errService");
      });
    });

    /* --- navigation between steps --- */
    function goTo(step) {
      current = step;
      panels.forEach(p => p.classList.toggle("active", Number(p.dataset.panel) === step));
      stepEls.forEach(s => {
        const n = Number(s.dataset.step);
        s.classList.toggle("active", n === step);
        s.classList.toggle("done", n < step);
      });
      // scroll booking card into comfortable view
      const card = $(".booking__card");
      if (card) {
        const y = card.getBoundingClientRect().top + window.scrollY - 110;
        window.scrollTo({ top: y, behavior: reduceMotion ? "auto" : "smooth" });
      }
    }

    function showError(id) { const e = $("#"+id); if (e) e.classList.add("show"); }
    function clearError(id) { const e = $("#"+id); if (e) e.classList.remove("show"); }

    function validateStep(step) {
      if (step === 1) {
        if (!state.service) { showError("errService"); return false; }
        return true;
      }
      if (step === 2) {
        let ok = true;
        if (!dateInput.value) { showError("errDate"); $("#date").classList.add("invalid"); ok = false; }
        else { clearError("errDate"); $("#date").classList.remove("invalid"); }
        if (!state.time) { showError("errTime"); ok = false; }
        return ok;
      }
      return true;
    }

    $$("[data-next]", form).forEach(btn => {
      btn.addEventListener("click", () => {
        if (validateStep(current)) {
          state.date = dateInput.value;
          goTo(current + 1);
        }
      });
    });
    $$("[data-prev]", form).forEach(btn => {
      btn.addEventListener("click", () => goTo(current - 1));
    });

    /* --- live field validation (step 3) --- */
    const nameI = $("#fullname"), phoneI = $("#phone"), emailI = $("#email"), notesI = $("#notes");
    const phoneOk = v => /^[0-9+\-\s()]{9,15}$/.test(v.trim());
    const emailOk = v => v.trim() === "" || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim());

    function validateDetails() {
      let ok = true;
      if (nameI.value.trim().length < 2) { showError("errName"); nameI.classList.add("invalid"); ok = false; }
      else { clearError("errName"); nameI.classList.remove("invalid"); }
      if (!phoneOk(phoneI.value)) { showError("errPhone"); phoneI.classList.add("invalid"); ok = false; }
      else { clearError("errPhone"); phoneI.classList.remove("invalid"); }
      if (!emailOk(emailI.value)) { showError("errEmail"); emailI.classList.add("invalid"); ok = false; }
      else { clearError("errEmail"); emailI.classList.remove("invalid"); }
      return ok;
    }
    [nameI, phoneI, emailI].forEach(i => i.addEventListener("input", () => {
      // clear error as user corrects
      if (i === nameI && nameI.value.trim().length >= 2) { clearError("errName"); nameI.classList.remove("invalid"); }
      if (i === phoneI && phoneOk(phoneI.value)) { clearError("errPhone"); phoneI.classList.remove("invalid"); }
      if (i === emailI && emailOk(emailI.value)) { clearError("errEmail"); emailI.classList.remove("invalid"); }
    }));

    /* --- helpers --- */
    function prettyDate(iso) {
      try {
        const d = new Date(iso + "T00:00:00");
        return d.toLocaleDateString("he-IL", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
      } catch { return iso; }
    }
    function priceLabel() {
      if (state.service === "חבילת חתן") return "בתיאום אישי";
      if (state.price === 0) return "לפי בקשה";
      if (state.service === "צביעת שיער") return "החל מ־₪" + state.price;
      return "₪" + state.price;
    }

    /* --- submit --- */
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      if (current !== 3) return;
      if (!validateDetails()) return;

      state.fullname = nameI.value.trim();
      state.phone = phoneI.value.trim();
      state.email = emailI.value.trim();
      state.notes = notesI.value.trim();

      // build summary
      const rows = [
        ["שירות", state.service],
        ["מחיר", priceLabel()],
        ["תאריך", prettyDate(state.date)],
        ["שעה", state.time],
        ["שם", state.fullname],
        ["טלפון", state.phone],
      ];
      if (state.email) rows.push(["אימייל", state.email]);
      if (state.notes) rows.push(["הערות", state.notes]);

      $("#confirmSummary").innerHTML = rows.map(([k, v]) =>
        `<div class="r"><span class="k">${k}</span><span class="v">${escapeHtml(v)}</span></div>`
      ).join("");

      // WhatsApp deep link
      const lines = [
        `*בקשת תור — ${CONFIG.businessName}*`,
        `שירות: ${state.service}`,
        `מחיר: ${priceLabel()}`,
        `תאריך: ${prettyDate(state.date)}`,
        `שעה: ${state.time}`,
        `שם: ${state.fullname}`,
        `טלפון: ${state.phone}`,
      ];
      if (state.email) lines.push(`אימייל: ${state.email}`);
      if (state.notes) lines.push(`הערות: ${state.notes}`);
      const wa = `https://wa.me/${CONFIG.whatsapp}?text=${encodeURIComponent(lines.join("\n"))}`;
      $("#waConfirm").href = wa;

      goTo(4);
      showToast("בקשת התור נשלחה בהצלחה!");
    });

    /* --- reset --- */
    $("[data-reset]", form).addEventListener("click", () => {
      form.reset();
      $$(".svc-opt").forEach(o => o.classList.remove("selected"));
      state.service = ""; state.price = 0; state.time = "";
      buildSlots();
      goTo(1);
    });

    /* --- deep links: service "book" buttons + preselect links --- */
    function preselectService(name) {
      const input = $$(".svc-opt input").find(i => i.value === name);
      if (input) { input.checked = true; input.dispatchEvent(new Event("change")); }
      goTo(1);
    }
    $$(".book-link").forEach(b => b.addEventListener("click", () => {
      preselectService(b.dataset.service);
      document.getElementById("booking").scrollIntoView({ behavior: reduceMotion ? "auto" : "smooth" });
    }));
    $$("[data-preselect]").forEach(b => b.addEventListener("click", () => {
      preselectService(b.dataset.preselect);
    }));
  }

  /* ---------------------------------------------------------------
     UTILITIES
     --------------------------------------------------------------- */
  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, c => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[c]));
  }

  let toastTimer;
  function showToast(msg) {
    const t = $("#toast"), m = $("#toastMsg");
    if (!t) return;
    m.textContent = msg;
    t.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove("show"), 4000);
  }

  /* current year in footer */
  const yearEl = $("#year");
  if (yearEl) yearEl.textContent = new Date().getFullYear();

})();
